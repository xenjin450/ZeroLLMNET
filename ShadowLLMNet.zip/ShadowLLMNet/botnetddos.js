const express = require('express');
const cookieParser = require('cookie-parser');
const readline = require('readline');
const axios = require('axios');  // Add axios for HTTP requests
const app = express();
const port = 80;

app.use(cookieParser());

let pendingResponses = {}; // Store pending responses for each route
let currentRoute = null; // Current route being interacted with
let clients = {}; // Store client information
let clientCounter = 1; // Counter for assigning client IDs
let clientRoutes = {}; // Store which routes are assigned to which clients

// Middleware for logging request information and identifying unique clients
app.use((req, res, next) => {
    console.log(`\nReceived ${req.method} request`);
    console.log('URL:', req.url);
    console.log('Headers:', req.headers);

    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    const userAgent = req.headers['user-agent'];
    const headersString = JSON.stringify(req.headers);

    // Generate a unique identifier based on IP, User-Agent, and headers
    const clientIdentifier = `${ip}-${userAgent}-${headersString}`;

    // Check if the client is new or existing
    if (!clients[clientIdentifier]) {
        const clientName = `Client${clientCounter++}`;
        clients[clientIdentifier] = { name: clientName, ip, userAgent, headers: req.headers };
        console.log(`New client identified: ${clientName}`);
    } else {
        console.log(`Existing client request from: ${clients[clientIdentifier].name}`);
    }

    const timezone = req.headers['x-timezone'] || 'Timezone info not available';
    console.log('Timezone Info:', timezone);

    console.log('Cookies:', req.cookies);
    console.log('User-Agent:', userAgent);
    console.log('Accept-Encoding:', req.headers['accept-encoding']);
    console.log('Referer:', req.headers['referer']);
    console.log('Connection:', req.headers['connection']);
    console.log('Priority:', req.headers['priority']);

    let bodyData = '';
    req.on('data', chunk => {
        bodyData += chunk;
    });

    req.on('end', () => {
        if (bodyData) {
            try {
                console.log('Body Data (Parsed):', JSON.parse(bodyData));
            } catch (e) {
                console.log('Body Data (Raw):', bodyData);
            }
        }
        next();
    });
});

// Cache control header for GET requests
app.use((req, res, next) => {
    if (req.method === 'GET') {
        res.setHeader('Cache-Control', 'public, max-age=86400'); // Cache for 1 day
    }
    next();
});

// Dynamic route handler to hold responses open indefinitely
app.get('*', (req, res) => {
    const route = req.url;
    console.log(`Request received on ${route}, holding response indefinitely...`);

    if (!pendingResponses[route]) {
        pendingResponses[route] = [];
    }

    pendingResponses[route].push(res);
    currentRoute = route;

    console.log('Active routes with pending responses:');
    for (let route in pendingResponses) {
        if (pendingResponses[route].length > 0) {
            console.log(`${route}: ${pendingResponses[route].length} pending requests`);
        }
    }

    // Assign the new route to the client that made the request
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    const userAgent = req.headers['user-agent'];
    const headersString = JSON.stringify(req.headers);
    const clientIdentifier = `${ip}-${userAgent}-${headersString}`;

    if (clients[clientIdentifier]) {
        const client = clients[clientIdentifier];
        if (!clientRoutes[client.name]) {
            clientRoutes[client.name] = [];
        }
        clientRoutes[client.name].push(route); // Assign this route to the client
        console.log(`Assigned route ${route} to client ${client.name}`);
    }
});

// Middleware to handle unmatched routes and set up indefinite holding
app.use((req, res, next) => {
    const statusCode = req.statusCode;

    if (
        req.method === 'GET' &&
        [200, 201, 301, 302, 303, 304, 305, 307, 401, 403, 404, 500, 502, 503, 504].includes(statusCode)
    ) {
        console.log(`${statusCode} captured for ${req.url}, holding response indefinitely...`);
        if (!pendingResponses[req.url]) {
            pendingResponses[req.url] = [];
        }
        pendingResponses[req.url].push(res);
        currentRoute = req.url;
    } else {
        res.status(400).json({ error: `Unsupported status code: ${statusCode}`, url: req.url });
    }
});

// Function to trigger a response with a specific status code
function triggerResponse(statusCode, redirectUrl) {
    if (currentRoute && pendingResponses[currentRoute] && pendingResponses[currentRoute].length > 0) {
        console.log(`Triggering ${statusCode} response and redirecting to ${redirectUrl} for route ${currentRoute}...`);
        let responseToSend = pendingResponses[currentRoute].shift();
        if (!responseToSend.headersSent) {
            if (statusCode >= 300 && statusCode < 400) {
                responseToSend.status(statusCode).redirect(redirectUrl);
            } else {
                responseToSend.status(statusCode).send({
                    message: `Triggered response with status code ${statusCode}`,
                });
            }
        }
    } else {
        console.log('No pending request for the current route.');
    }
}

// Function to trigger multiple routes for all clients
function triggerForAllClients(statusCode, redirectUrl) {
    console.log(`Triggering responses for all clients with status code ${statusCode}...`);

    // Loop through all clients and their assigned routes
    for (const clientName in clientRoutes) {
        clientRoutes[clientName].forEach(route => {
            console.log(`Triggering response for route ${route}...`);
            let responseToSend = pendingResponses[route] && pendingResponses[route].shift();
            if (responseToSend && !responseToSend.headersSent) {
                if (statusCode >= 300 && statusCode < 400) {
                    responseToSend.status(statusCode).redirect(redirectUrl);
                } else {
                    responseToSend.status(statusCode).send({
                        message: `Triggered response with status code ${statusCode}`,
                    });
                }
            }
        });

        // Optionally, send a request to the website for this client
        axios.get(redirectUrl)
            .then((response) => {
                console.log(`Request sent to ${redirectUrl} for client ${clientName} with status: ${response.status}`);
            })
            .catch((error) => {
                console.log('Error sending request:', error);
            });
    }
}

// Function to list all active indefinite routes
function listActiveRoutes() {
    console.log('Active indefinite routes with pending responses:');
    for (let route in pendingResponses) {
        if (pendingResponses[route].length > 0) {
            console.log(`${route}: ${pendingResponses[route].length} pending requests`);
        }
    }
}

// Function to list all clients and their assigned routes
function listClients() {
    console.log('Connected Clients:');
    for (const identifier in clients) {
        const client = clients[identifier];
        console.log(`${client.name}: IP=${client.ip}, User-Agent=${client.userAgent}`);
        if (clientRoutes[client.name]) {
            console.log(`Assigned Routes: ${clientRoutes[client.name].join(', ')}`);
        }
    }
}

// Start the server
app.listen(port, () => {
    console.log(`ShadowLLMNet running on http://localhost:${port}`);

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.on('line', (input) => {
        const args = input.trim().split(' ');
        const command = args[0].toLowerCase();

        switch (command) {
            case 'trigger':
                if (args.length >= 2) {
                    const statusCode = parseInt(args[1], 10);
                    const redirectUrl = args[2] || 'https://example.com/default';
                    triggerResponse(statusCode, redirectUrl);
                } else {
                    console.log('Usage: trigger <status_code> <redirect_url>');
                }
                break;

            case 'trigger-all':  // Command to trigger all clients
                if (args.length >= 2) {
                    const statusCode = parseInt(args[1], 10);
                    const redirectUrl = args[2] || 'https://example.com/default';
                    triggerForAllClients(statusCode, redirectUrl);
                } else {
                    console.log('Usage: trigger-all <status_code> <redirect_url>');
                }
                break;

            case 'reset':
                if (currentRoute && pendingResponses[currentRoute].length > 0) {
                    console.log('Resetting pending request...');
                    let responseToReset = pendingResponses[currentRoute].shift();
                    if (!responseToReset.headersSent) {
                        responseToReset.status(400).json({
                            message: 'Request has been reset by terminal command.',
                            status: '400 Bad Request'
                        });
                    }
                } else {
                    console.log('No pending request to reset.');
                }
                break;

            case 'list':
                listActiveRoutes();
                break;

            case 'clients':
                listClients();
                break;

            default:
                console.log(`Unknown command: ${input}`);
                console.log('Available commands: trigger <status_code> <redirect_url>, trigger-all <status_code> <redirect_url>, reset, list, clients');
                break;
        }
    });
});
