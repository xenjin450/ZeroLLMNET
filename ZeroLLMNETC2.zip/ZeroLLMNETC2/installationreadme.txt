apt-get install npm 
npm install axios && npm install cookie-parser && npm install express && npm install read readline
npm init -y